package com.example.latihanrecyclerview

import android.os.Parcel
import android.os.Parcelable

data class identitas(
    var Nama : String?,
    var Umur : String?,
    var Alamat : String?,
    var Hobby : String?
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(Nama)
        parcel.writeString(Umur)
        parcel.writeString(Alamat)
        parcel.writeString(Hobby)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<identitas> {
        override fun createFromParcel(parcel: Parcel): identitas {
            return identitas(parcel)
        }

        override fun newArray(size: Int): Array<identitas?> {
            return arrayOfNulls(size)
        }
    }
}

