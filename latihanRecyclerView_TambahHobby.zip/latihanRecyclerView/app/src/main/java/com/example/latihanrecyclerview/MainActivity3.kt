package com.example.latihanrecyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val _imageDetail : ImageView = findViewById(R.id.imageDetail)
        val _textDetailNama : TextView = findViewById(R.id.textDetailNama)
        val _textDetailUmur : TextView = findViewById(R.id.textDetailUmur)
        val _textDetailAlamat : TextView = findViewById(R.id.textDetailAlamat)
        val _textDetailHobby : TextView = findViewById(R.id.textDetailHobby)

        val dataIntent = intent.getParcelableExtra<identitas>("kirimData")

        _textDetailNama.setText(dataIntent!!.Nama)
        _textDetailUmur.setText(dataIntent!!.Umur)
        _textDetailAlamat.setText(dataIntent!!.Alamat)
        _textDetailHobby.setText(dataIntent!!.Hobby)
    }
}