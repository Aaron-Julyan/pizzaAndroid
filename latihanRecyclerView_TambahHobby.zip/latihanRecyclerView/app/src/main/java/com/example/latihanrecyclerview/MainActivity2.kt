package com.example.latihanrecyclerview

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity2 : AppCompatActivity() {

    private lateinit var _rvIdentitas: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        _rvIdentitas = findViewById(R.id.tampilan1)

        fun TampilkanData() {
            _rvIdentitas.layoutManager = LinearLayoutManager(this)
            val ambilArrIdentitas = intent.getParcelableArrayListExtra<identitas>("Data")
            val identitasAdapter = adapterIdentitas(ambilArrIdentitas!!)
            _rvIdentitas.adapter = identitasAdapter


            identitasAdapter.setOnItemClickCallback(object : adapterIdentitas.OnItemClickCallback {

                override fun onItemClicked(data: identitas) {
                    val intent = Intent(this@MainActivity2, MainActivity3::class.java)
                    intent.putExtra("kirimData", data)
                    startActivity(intent)
                }

                override fun delData(pos: Int) {
                    AlertDialog.Builder(this@MainActivity2)
                        .setTitle("HAPUS DATA")
                        .setMessage("APAKAH BENAR DATA " + ambilArrIdentitas!![pos] + " akan dihapus ? ")
                        .setPositiveButton(
                            "HAPUS",
                            DialogInterface.OnClickListener { dialog, which ->
                                ambilArrIdentitas.removeAt(pos)
                                TampilkanData()
                            })
                        .setNegativeButton(
                            "BATAL",
                            DialogInterface.OnClickListener { dialog, which ->
                                Toast.makeText(
                                    this@MainActivity2,
                                    "DATA BATAL DIHAPUS",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }).show()
                }

                //            Override fun onItemClicked(data : identitas){
//                TampilkanData()
//            }
            })
        }
        TampilkanData()
    }
}