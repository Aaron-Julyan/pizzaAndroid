package com.example.latihanrecyclerview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    var _nama = mutableListOf<String>()
    var _umur = mutableListOf<String>()
    var _alamat = mutableListOf<String>()
    var _hobby = mutableListOf<String>()

    private var arrIdentitas = arrayListOf<identitas>()

    //private lateinit var _rvIdentitas : RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val _buttonSubmit : Button = findViewById(R.id.buttonSubmit)
        val _buttonPindah : Button = findViewById(R.id.buttonPindah)
        val _editNama : EditText = findViewById(R.id.editNama)
        val _editUmur : EditText = findViewById(R.id.editUmur)
        val _editAlamat : EditText = findViewById(R.id.editAlamat)
        val _editHobby : EditText = findViewById(R.id.editHobby)

        //_rvIdentitas = findViewById(R.id.tampilan)

        _buttonSubmit.setOnClickListener{
            _nama.add(_editNama.text.toString())
            _umur.add(_editUmur.text.toString())
            _alamat.add(_editAlamat.text.toString())
            _hobby.add(_editHobby.text.toString())
            arrIdentitas.clear()
            TambahData()
            //TampilkanData()

            _editNama.text.clear()
            _editUmur.text.clear()
            _editAlamat.text.clear()
            _editHobby.text.clear()
        }

        _buttonPindah.setOnClickListener{
            val intent_activity2 = Intent(this@MainActivity, MainActivity2::class.java).apply {
                putExtra("Data", arrIdentitas)
            }
            startActivity(intent_activity2)
        }
    }

    private fun TambahData(){
        for (position in _nama.indices){
            val data = identitas(
                _nama[position],
                _umur[position],
                _alamat[position],
                _hobby[position]
            )

            arrIdentitas.add(data)
        }
    }

    fun HapusData(identitas : identitas){
        _nama.remove(identitas.Nama)
        _umur.remove(identitas.Umur)
        _alamat.remove(identitas.Alamat)
        _hobby.remove(identitas.Hobby)
        arrIdentitas.clear()
        TambahData()
    }

//    private fun TampilkanData(){
//        _rvIdentitas.layoutManager = LinearLayoutManager(this)
//        val identitasAdapter = adapterIdentitas(arrIdentitas)
//        _rvIdentitas.adapter = identitasAdapter
//    }
}