package com.example.latihanrecyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class adapterIdentitas (private val listIdentitas : ArrayList<identitas>) :
    RecyclerView.Adapter<adapterIdentitas.ListViewHolder>() {

    private lateinit var onItemClickCallback : OnItemClickCallback

    interface OnItemClickCallback {
        fun onItemClicked(data : identitas)
        fun delData(pos : Int)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback){
        this.onItemClickCallback = onItemClickCallback
    }

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var _textNama : TextView = itemView.findViewById(R.id.textNama)
        var _textUmur : TextView = itemView.findViewById(R.id.textUmur)
        var _textAlamat : TextView = itemView.findViewById(R.id.textAlamat)
        var _textHobby : TextView = itemView.findViewById(R.id.textHobby)
        var _buttonHapus : Button = itemView.findViewById(R.id.buttonHapus)
        var _cardIdentitas : CardView = itemView.findViewById(R.id.cardIdentitas)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): adapterIdentitas.ListViewHolder {
        val view : View = LayoutInflater.from(parent.context)
            .inflate(R.layout.itemidentitas, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: adapterIdentitas.ListViewHolder, position: Int) {
        var var_identitas = listIdentitas[position]
        holder._textNama.setText(var_identitas.Nama)
        holder._textUmur.setText(var_identitas.Umur)
        holder._textAlamat.setText(var_identitas.Alamat)
        holder._textHobby.setText(var_identitas.Hobby)
        holder._buttonHapus.setOnClickListener{
            onItemClickCallback.delData(position)
        }
        holder._cardIdentitas.setOnClickListener{
            onItemClickCallback.onItemClicked(listIdentitas[position])
        }
    }

    override fun getItemCount(): Int {
        return listIdentitas.size
    }
}